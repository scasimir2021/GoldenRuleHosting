# Golden Rule Hosting — HTML-only Demo

Contents:
- `index.html` (or `golden-rule-hosting.html`): Single-file website demo (no backend).
- `BLUEPRINT_FRAMEWORK_v7_2_COMPLETE.md`: Blueprint framework reference.

Notes:
- Forms and the portal demo store data in `localStorage` (browser-only).
- Replace demo contact details, vendor links, and portfolio links before going live.
